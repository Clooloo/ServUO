using System;
using Server;
using Server.Items;
using Server.Gumps;
using Server.Multis;
using Server.Network;
using Server.Targeting;

namespace Server.Items
{
	public class NewHolidayTreeAddon : BaseAddon
	{
		public override BaseAddonDeed Deed{ get{ return new HolidayTreeDeed(); } }

		[Constructable]
		public NewHolidayTreeAddon( bool modern )
		{

			if( !modern )
			{
				AddComponent( new LocalizedAddonComponent( 0xCD7, 1041117 ),  0,  0, 0 ); // Classic

				AddOrnament( -1, -1, -11, 0xCD6, 1041117 );

				AddOrnament( 0, 0,  2, 0xF22 );
				AddOrnament( 0, 0,  9, 0xF18 );
				AddOrnament( 0, 0, 15, 0xF20 );
				AddOrnament( 0, 0, 19, 0xF17 );
				AddOrnament( 0, 0, 20, 0xF24 );
				AddOrnament( 0, 0, 20, 0xF1F );
				AddOrnament( 0, 0, 20, 0xF19 );
				AddOrnament( 0, 0, 21, 0xF1B );
				AddOrnament( 0, 0, 28, 0xF2F );
				AddOrnament( 0, 0, 30, 0xF23 );
				AddOrnament( 0, 0, 32, 0xF2A );
				AddOrnament( 0, 0, 33, 0xF30 );
				AddOrnament( 0, 0, 34, 0xF29 );
				AddOrnament( 0, 1,  7, 0xF16 );
				AddOrnament( 0, 1,  7, 0xF1E );
				AddOrnament( 0, 1, 12, 0xF0F );
				AddOrnament( 0, 1, 13, 0xF13 );
				AddOrnament( 0, 1, 18, 0xF12 );
				AddOrnament( 0, 1, 19, 0xF15 );
				AddOrnament( 0, 1, 25, 0xF28 );
				AddOrnament( 0, 1, 29, 0xF1A );
				AddOrnament( 0, 1, 37, 0xF2B );
				AddOrnament( 1, 0, 13, 0xF10 );
				AddOrnament( 1, 0, 14, 0xF1C );
				AddOrnament( 1, 0, 16, 0xF14 );
				AddOrnament( 1, 0, 17, 0xF26 );
				AddOrnament( 1, 0, 22, 0xF27 );
			}
			else
			{
				AddComponent( new LocalizedAddonComponent( 0x1B7E, 1041117 ),  0,  0, 0 ); // Modern

				AddOrnament( 0, 0,  2, 0xF2F );
				AddOrnament( 0, 0,  2, 0xF20 );
				AddOrnament( 0, 0,  2, 0xF22 );
				AddOrnament( 0, 0,  5, 0xF30 );
				AddOrnament( 0, 0,  5, 0xF15 );
				AddOrnament( 0, 0,  5, 0xF1F );
				AddOrnament( 0, 0,  5, 0xF2B );
				AddOrnament( 0, 0,  6, 0xF0F );
				AddOrnament( 0, 0,  7, 0xF1E );
				AddOrnament( 0, 0,  7, 0xF24 );
				AddOrnament( 0, 0,  8, 0xF29 );
				AddOrnament( 0, 0,  9, 0xF18 );
				AddOrnament( 0, 0, 14, 0xF1C );
				AddOrnament( 0, 0, 15, 0xF13 );
				AddOrnament( 0, 0, 15, 0xF20 );
				AddOrnament( 0, 0, 16, 0xF26 );
				AddOrnament( 0, 0, 17, 0xF12 );
				AddOrnament( 0, 0, 18, 0xF17 );
				AddOrnament( 0, 0, 20, 0xF1B );
				AddOrnament( 0, 0, 23, 0xF28 );
				AddOrnament( 0, 0, 25, 0xF18 );
				AddOrnament( 0, 0, 25, 0xF2A );
				AddOrnament( 0, 1,  7, 0xF16 );
			}
		}

		private void AddOrnament( int x, int y, int z, int itemID )
		{
			AddOrnament( x, y, z, itemID, 1041118 );
		}

		private void AddOrnament( int x, int y, int z, int itemID, int labelnumber )
		{
			AddComponent( new Ornament( itemID, labelnumber ),  x+1,  y+1, z+11 );
		}

		public NewHolidayTreeAddon( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}

		private class Ornament : AddonComponent
		{
			public override int LabelNumber{ get{ return m_labelnumber; } } // a tree ornament
			private int m_labelnumber;

			public Ornament( int itemID, int labelnumber ) : base( itemID )
			{
				Movable = false;
				m_labelnumber = labelnumber;
			}

			public Ornament( Serial serial ) : base( serial )
			{
			}

			public override void Serialize( GenericWriter writer )
			{
				base.Serialize( writer );

				writer.Write( (int)0  ); // version

				writer.Write( m_labelnumber );
			}

			public override void Deserialize( GenericReader reader )
			{
				base.Deserialize( reader );

				int version = reader.ReadInt();

				m_labelnumber = reader.ReadInt();
			}
		}
	}

	public class HolidayTreeDeed : BaseAddonDeed
	{
		public override BaseAddon Addon{ get{ return SelectedAddon; } }
		public BaseAddon SelectedAddon = new NewHolidayTreeAddon( false );
		public override int LabelNumber{ get{ return 1041116; } } // a deed for a holiday tree

		[Constructable]
		public HolidayTreeDeed()
		{
			LootType = LootType.Blessed;

		}

		public HolidayTreeDeed( Serial serial ) : base( serial )
		{
		}

		public override void OnDoubleClick( Mobile from )
		{
			if ( from.AccessLevel == AccessLevel.Player && DateTime.Now.Month != 12 )
			{
				from.SendLocalizedMessage( 1005700 ); // You will have to wait till next December to put your tree back up for display.
				return;
			}

			from.CloseGump( typeof( HolidayTreeChoiceGump ) );
			from.SendGump( new HolidayTreeChoiceGump( from, this ) );
		}

		public void BeginPlace( Mobile from )
		{
			base.OnDoubleClick( from );
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}

		public class HolidayTreeChoiceGump : Gump
		{
			private Mobile m_From;
			private HolidayTreeDeed m_Deed;

			public HolidayTreeChoiceGump( Mobile from, HolidayTreeDeed deed ) : base( 200, 200 )
			{
				m_From = from;
				m_Deed = deed;

				AddPage( 0 );

				AddBackground( 0, 0, 220, 120, 5054 );
				AddBackground( 10, 10, 200, 100, 3000 );

				AddButton( 20, 35, 4005, 4007, 1, GumpButtonType.Reply, 0 );
				AddHtmlLocalized( 55, 35, 145, 25, 1018322, false, false ); // Classic

				AddButton( 20, 65, 4005, 4007, 2, GumpButtonType.Reply, 0 );
				AddHtmlLocalized( 55, 65, 145, 25, 1018321, false, false ); // Modern
			}

			public override void OnResponse( NetState sender, RelayInfo info )
			{
				if ( m_Deed.Deleted )
					return;

				switch ( info.ButtonID )
				{
					case 1:
					{
						m_Deed.SelectedAddon = new NewHolidayTreeAddon( false );
						m_Deed.BeginPlace( m_From );
						break;
					}
					case 2:
					{
						m_Deed.SelectedAddon = new NewHolidayTreeAddon( true );
						m_Deed.BeginPlace( m_From );
						break;
					}
				}
			}
		}
	}
}